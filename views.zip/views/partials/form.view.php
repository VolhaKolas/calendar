<div class="container">
    <div class="col-md-3 col-sm-3">
        <div class="form-area">
            <form role="form" enctype="multipart/form-data" method="post" action="">
                <div class="form-group">
                    <input type="text" class="form-control" id="year" name="year" required>
                </div>

                <button id="submit" class="btn pull-right">Введите год</button>
            </form>
        </div>
    </div>
</div>